num = int(input("Enter a number : "))

if num % 2 == 0:
    print("Number is even")
else:
    print("Number is odd")


'''
Output
Enter a number : 26
Number is even
Enter a number : 15
Number is odd
'''