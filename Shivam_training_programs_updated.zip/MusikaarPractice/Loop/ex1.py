num = int(input("Enter number to get sum : "))

total = 0
for i in range(1, num + 1):
    total = i + total

print(total)


'''
Output

Enter number to get sum : 6
21
'''