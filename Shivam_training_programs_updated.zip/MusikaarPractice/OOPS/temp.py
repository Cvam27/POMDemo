mrk = int(input("marks"))
if mrk < 0 or mrk >50:
    print("invalid")
